<?php
header('Content-Type: application/json; charset=utf-8');
echo '{"status":"success","message":"API is working!","timestamp":"' . date('Y-m-d H:i:s') . '"}';
?>